let step = 0;
let userData = {
    nome: '',
    email: '',
    cpf: ''
};

const chatbotMessages = document.getElementById('chatbot-messages');

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('chatbot-input');
    const message = input.value.trim();
    if (message) {
        addMessage(message, 'user-message');
        input.value = '';
        handleUserResponse(message);
    }
}

function addMessage(message, className) {
    const p = document.createElement('p');
    p.textContent = message;
    p.className = className;
    chatbotMessages.appendChild(p);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function handleUserResponse(message) {
    switch (step) {
        case 0:
            userData.nome = message;
            addMessage('Qual é o seu email?', 'bot-message');
            step++;
            break;
        case 1:
            userData.email = message;
            addMessage('Qual é o seu CPF?', 'bot-message');
            step++;
            break;
        case 2:
            userData.cpf = message;
            addMessage(`Obrigado, ${userData.nome}! Como posso ajudá-lo?`, 'bot-message');
            step++;
            break;
        default:
            handleFAQ(message);
            break;
    }
}

function handleFAQ(message) {
    const lowerMessage = message.toLowerCase();
    if (lowerMessage.includes('reserva')) {
        addMessage('Para fazer uma reserva, acesse a seção de Acomodações em nosso site.', 'bot-message');
    } else if (lowerMessage.includes('preço') || lowerMessage.includes('valor')) {
        addMessage('Os preços variam de acordo com o tipo de acomodação e a época do ano. Para mais detalhes, visite a seção de Acomodações.', 'bot-message');
    } else if (lowerMessage.includes('localização')) {
        addMessage('Estamos localizados na Rua da Pousada, 123, Cidade, Estado.', 'bot-message');
    } else if (lowerMessage.includes('contato')) {
        addMessage('Você pode nos contatar pelo telefone (99) 9999-9999 ou pelo email contato@quintadoypua.com.br.', 'bot-message');
    } else {
        addMessage('Desculpe, não entendi sua pergunta. Você pode repetir?', 'bot-message');
    }
}

// Iniciar a conversa
document.addEventListener('DOMContentLoaded', () => {
    addMessage('Olá! Qual é o seu nome?', 'bot-message');
});
